# B012ED packages

what is B012ED packages toola?<br>
B012ED packages is a tool to install all base packages in termux application
**how to install and usage:**

**Termux:**
* `pkg install python`
* `pip2 install requests`
* `pkg install git`
* `git clone https://github.com/B012ED/pkg.git`
* `unzip pkg`
* `cd pkg`
* `chmod +x pkg.py`
* `python pkg.py`

**Linux:**
* `apt-get install python`
* `apt-get install pthon-pip`
* `pip install requests`
* `apt-get install git`
* `git clone https://github.com/B012ED/pkg.git`
* `unzip pkg`
* `cd pkg`
* `chmod +x pkg.py`
* `python pkg.py`

**NOTE:** don't forget to be happy !!


